<h2><b>About this Mod:</b></h2>
A Modpack that aims to add an element of roleplay and Quality of life changes to Valheim.  The focus is on skills to improve aspects of the game and the addition of Magic through Runes, Jewelcrafting, Alchemy and Necromancy.
<br>
Each Mod is selected by myself and my wife for our home server to play together with our kids and eachother.
<br>
Feel free to use this modpack for your own server and for admin tools please see <a href="https://valheim.thunderstore.io/package/Vidar/WotW_Admin_tools/">WotW Admin Tools Modpack</a>

<h2><b>Changelog</b></h2>
<p><b>1.2.0</b></br>
Removed Dverger Pieces.</br>
Added Balronds Dverger furniture.</br>
Added balrond Furnature.</br>
Added balrond Containers.</br>
Added Professions.</br>
Added Packmule.</br>
Added Passive Powers.</br>
Added Tripple Bronze.</br>
</p>
<p><b>1.1.8</b></br>
Removed Clutter Sign Component Fix.</br>
Added Southsil Armor.</br>
Added balrond shipyard</br>
</p>
<p><b>1.1.5</b></br>
Removed <a href="https://valheim.thunderstore.io/package/Blockheim/LetMeSleep/">LetMeSleep</a> until it is fixed, it is preventing players from sleeping.<br>
Added Clutter Sign Component Fix.
</p>
<p><b>1.1.4</b></br>
Started tracking changes<br>
Removed Multicraft and replaced with <a href="https://valheim.thunderstore.io/package/Azumatt/AAA_Crafting/">AAA Crafting</a><br>
Updated Adventure Backpacks<br>
Removed MultiFarm
</p>
<p><b>1.0.0 to 1.1.4</b><br>
Many updates</p>